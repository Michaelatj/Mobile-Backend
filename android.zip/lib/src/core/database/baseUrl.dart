class BaseUrl {
  static const String reviews =
      'https://68f9c893ef8b2e621e7d69f4.mockapi.io/bantuin/api/review';
}
